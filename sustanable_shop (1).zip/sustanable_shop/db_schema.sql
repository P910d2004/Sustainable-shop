-- Database Schema (db_schema.sql)

CREATE DATABASE sustainable_shop;

USE sustainable_shop;

-- Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255),
    category VARCHAR(100),
    stock INT NOT NULL,
    eco_rating ENUM('A', 'B', 'C', 'D', 'E') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO products (name, description, price, image, category, stock, eco_rating) VALUES
('Backpack', 'Eco-friendly backpack made from sustainable materials', 49.99, '/images/backpack.jpg', 'Accessories', 50, 'A'),
('beeswax_wraps', 'Reusable beeswax wraps for food storage', 19.99, '/images/beeswax_wraps.jpg', 'Kitchen', 100, 'A'),
('bottle', 'Stainless steel reusable water bottle', 25.99, '/images/bottle.jpg', 'Drinkware', 80, 'A'),
('cleaning_kit', 'Eco-friendly cleaning kit with natural ingredients', 29.99, '/images/cleaning_kit.jpg', 'Household', 60, 'A'),
('food_containers', 'Biodegradable food containers', 22.99, '/images/food_containers.jpg', 'Kitchen', 70, 'A'),
('garden_lights', 'Solar-powered garden lights', 34.99, '/images/garden_lights.jpg', 'Outdoor', 40, 'A'),
('glass_jars', 'Reusable glass jars for storage', 15.99, '/images/glass_jars.jpg', 'Kitchen', 90, 'A'),
('glass_straws', 'Set of reusable glass straws', 12.99, '/images/glass_straws.jpg', 'Drinkware', 120, 'A'),
('hairbrush', 'Wooden hairbrush made from sustainable materials', 14.99, '/images/hairbrush.jpg', 'Personal Care', 80, 'A'),
('makeup_pads', 'Reusable cotton makeup remover pads', 17.99, '/images/makeup_pads.jpg', 'Personal Care', 110, 'A'),
('notebook', 'Recycled paper notebooks', 9.99, '/images/notebook.jpg', 'Stationery', 150, 'A'),
('phone_case', 'Biodegradable phone case', 19.99, '/images/phone_case.jpg', 'Accessories', 60, 'A'),
('powerbank', 'Solar-powered power bank', 39.99, '/images/powerbank.jpg', 'Electronics', 45, 'A'),
('silicone_bags', 'Reusable silicone food storage bags', 24.99, '/images/silicone_bags.jpg', 'Kitchen', 100, 'A'),
('tea_set', 'Eco-friendly ceramic tea set', 49.99, '/images/tea_set.jpg', 'Kitchen', 30, 'A'),
('toothbrush', 'Bamboo toothbrush set', 10.99, '/images/toothbrush.jpg', 'Personal Care', 150, 'A'),
('towels', 'Organic cotton towels', 29.99, '/images/towels.jpg', 'Home', 70, 'A'),
('trash_bags', 'Compostable trash bags', 18.99, '/images/trash_bags.jpg', 'Household', 90, 'A'),
('Tshirt1', 'Organic cotton T-shirt', 22.99, '/images/tshirt1.jpg', 'Clothing', 75, 'A'),
('yogamat', 'Eco-friendly yoga mat made from natural rubber', 59.99, '/images/yogamat.jpg', 'Fitness', 40, 'A');


-- Cart Table
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Orders Table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_details TEXT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    email VARCHAR(255) NOT NULL,
    status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
 
